package com.debasishalder.airapplauncher;

import java.io.File;
import android.content.Intent;
import android.net.Uri;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;
import com.debasishalder.airapplauncher.LauncherContext;

public class LaunchApp implements FREFunction  {

	@Override
	public FREObject call(FREContext arg0, FREObject[] arg1) {
		LauncherContext ACTDEC=(LauncherContext)arg0;
		try
		{
			String URLANDMIME=arg1[0].getAsString();
			int N =URLANDMIME.indexOf("*");
			String URL = URLANDMIME.substring(0, N);
			String MIME = URLANDMIME.substring(N+1, URLANDMIME.length());
			android.util.Log.e("AIR_App_Launch",URL);
			android.util.Log.i("AIR_App_Launch",URL);
			android.util.Log.e("AIR_App_Launch",MIME);
			File file = new File(URL);
			file.setExecutable(true);	
			Intent viewIntent = new Intent();
		    viewIntent.setAction(Intent.ACTION_VIEW);
		    viewIntent.setDataAndType(Uri.fromFile(file), MIME);
		    ACTDEC.activity.startActivity(viewIntent);

		}
		catch(Exception e)
		{
			android.util.Log.e("AIR_App_Launch_Error ",e.getMessage());
		}finally{
			android.util.Log.e("AIR_App_Launch","Air Android Communication successfull");
		}
		return null;
	}

}
