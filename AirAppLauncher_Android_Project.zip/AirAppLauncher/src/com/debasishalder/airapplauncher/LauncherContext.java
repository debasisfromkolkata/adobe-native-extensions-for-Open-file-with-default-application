package com.debasishalder.airapplauncher;

import java.util.Map;

import android.app.Activity;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;

public class LauncherContext extends FREContext {
	public Activity activity;
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<String, FREFunction> getFunctions() {
		Map<String,FREFunction> functionMap=new java.util.HashMap<String,FREFunction>();
		functionMap.put("LaunchApp",new LaunchApp());
		functionMap.put("LaunchInit",new LauncherInit());

		return functionMap;
	//	return null;
	}

}
