/** Automatically generated file. DO NOT MODIFY */
package com.nucleusmind.airapplauncher;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}